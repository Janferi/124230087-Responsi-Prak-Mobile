Letakkan file zalora.png di folder ini.
File logo harus berformat PNG dengan nama: zalora.png
