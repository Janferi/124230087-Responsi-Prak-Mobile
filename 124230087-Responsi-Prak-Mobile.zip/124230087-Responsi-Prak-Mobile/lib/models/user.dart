import 'package:hive/hive.dart';

part 'user.g.dart';

@HiveType(typeId: 0)
class User {
  @HiveField(0)
  final String username;

  @HiveField(1)
  final String password;

  @HiveField(2)
  final String? name;

  @HiveField(3)
  final String? nim;

  @HiveField(4)
  final String? photoPath;

  User({
    required this.username,
    required this.password,
    this.name,
    this.nim,
    this.photoPath,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      username: map['username'] as String,
      password: map['password'] as String,
      name: map['name'] as String?,
      nim: map['nim'] as String?,
      photoPath: map['photoPath'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'password': password,
      'name': name,
      'nim': nim,
      'photoPath': photoPath,
    };
  }
}
