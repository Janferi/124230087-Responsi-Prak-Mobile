import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../local/shared_pref.dart';

class AuthController extends ChangeNotifier {
  bool _loading = false;
  String? _currentUsername;
  bool get loading => _loading;
  String? get currentUsername => _currentUsername;

  Future<void> initSession() async {
    _setLoading(true);
    _currentUsername = await SharedPref.getSession();
    _setLoading(false);
    notifyListeners();
  }

  Future<void> register({
    required String username,
    required String password,
    String? name,
    String? nim,
    String? photoPath,
  }) async {
    _setLoading(true);
    try {
      if (await SharedPref.isUserRegistered(username)) {
        throw Exception('Username Sudah Terdaftar');
      }

      final user = User(
        username: username,
        password: password,
        name: name,
        nim: nim,
        photoPath: photoPath,
      );
      await SharedPref.saveUser(user);
    } finally {
      _setLoading(false);
      notifyListeners();
    }
  }

  Future<bool> login(String username, String password) async {
    _setLoading(true);
    try {
      final ok = await SharedPref.validateUser(username, password);
      if (ok) {
        await SharedPref.saveSession(username);
        _currentUsername = username;
        notifyListeners();
      }
      return ok;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> logout() async {
    _setLoading(true);
    await SharedPref.clearSession();
    _currentUsername = null;
    _setLoading(false);
    notifyListeners();
  }

  Future<User?> getProfile() async {
    final username = await SharedPref.getSession();
    if (username == null) return null;
    return SharedPref.getUser(username);
  }

  Future<void> updateProfile(User user) async {
    _setLoading(true);
    try {
      await SharedPref.saveUser(user);
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }
}
