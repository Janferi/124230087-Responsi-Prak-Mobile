import 'package:flutter/foundation.dart';
import '../models/product.dart';
import '../services/api_service.dart';

class ProductController extends ChangeNotifier {
  final ApiService _api = ApiService();

  
  bool _loading = false;
  List<Product> _items = [];
  List<String> _categories = [];
  String? _selectedCategory;

  
  bool get loading => _loading;
  List<Product> get items => _items;
  List<String> get categories => _categories;
  String? get selectedCategory => _selectedCategory;

    Future<void> loadProducts() async {
    _setLoading(true);
    try {
      _items = await _api.getProducts();
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error loading products: $e');
      }
    } finally {
      _setLoading(false);
    }
  }

    Future<void> loadCategories() async {
    try {
      _categories = await _api.getCategories();
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error loading categories: $e');
      }
    }
  }

    Future<void> filterByCategory(String? category) async {
    _selectedCategory = category;
    _setLoading(true);
    try {
      if (category == null || category.isEmpty) {
        _items = await _api.getProducts();
      } else {
        _items = await _api.getProductsByCategory(category);
      }
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error filtering products: $e');
      }
    } finally {
      _setLoading(false);
    }
  }

    void clearFilter() {
    _selectedCategory = null;
    loadProducts();
  }

  void _setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }
}
