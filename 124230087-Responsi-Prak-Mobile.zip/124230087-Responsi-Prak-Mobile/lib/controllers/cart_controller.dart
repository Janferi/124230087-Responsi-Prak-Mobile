import 'package:flutter/foundation.dart';
import '../models/product.dart';
import '../local/shared_pref.dart';
import '../services/api_service.dart';

class CartController extends ChangeNotifier {
  final ApiService _api = ApiService();

  List<Product> _cartItems = [];
  bool _loading = false;

  List<Product> get cartItems => _cartItems;
  bool get loading => _loading;

  Future<void> loadCart() async {
    _setLoading(true);
    try {
      final productIds = await SharedPref.getCartProductIds();
      _cartItems = [];

      for (int id in productIds) {
        try {
          final product = await _api.getProductDetail(id);
          _cartItems.add(product);
        } catch (e) {
          if (kDebugMode) {
            print('Error loading product $id: $e');
          }
        }
      }
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addToCart(Product product) async {
    await SharedPref.addToCart(product.id);
    await loadCart();
  }

  Future<void> removeFromCart(int productId) async {
    await SharedPref.removeFromCart(productId);
    await loadCart();
  }

  Future<bool> isInCart(int productId) async {
    return await SharedPref.isInCart(productId);
  }

  double getTotalPrice() {
    return _cartItems.fold(0.0, (sum, item) => sum + item.price);
  }

  void _setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }
}
