import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/product.dart';

class ApiService {
  static const String _base = 'https://fakestoreapi.com';

  Future<List<Product>> getProducts() async {
    final uri = Uri.parse('$_base/products');
    final resp = await http.get(uri);
    if (resp.statusCode != 200) {
      throw Exception('Failed to fetch products (${resp.statusCode})');
    }
    final List<dynamic> jsonList = json.decode(resp.body) as List<dynamic>;
    return jsonList
        .map((item) => Product.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<List<Product>> getProductsByCategory(String category) async {
    final uri = Uri.parse('$_base/products/category/$category');
    final resp = await http.get(uri);
    if (resp.statusCode != 200) {
      throw Exception(
          'Failed to fetch products by category (${resp.statusCode})');
    }
    final List<dynamic> jsonList = json.decode(resp.body) as List<dynamic>;
    return jsonList
        .map((item) => Product.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<List<String>> getCategories() async {
    final uri = Uri.parse('$_base/products/categories');
    final resp = await http.get(uri);
    if (resp.statusCode != 200) {
      throw Exception('Failed to fetch categories (${resp.statusCode})');
    }
    final List<dynamic> jsonList = json.decode(resp.body) as List<dynamic>;
    return jsonList.map((item) => item.toString()).toList();
  }

  Future<Product> getProductDetail(int id) async {
    final uri = Uri.parse('$_base/products/$id');
    final resp = await http.get(uri);
    if (resp.statusCode != 200) {
      throw Exception('Failed to fetch product detail (${resp.statusCode})');
    }
    final Map<String, dynamic> jsonMap =
        json.decode(resp.body) as Map<String, dynamic>;
    return Product.fromJson(jsonMap);
  }
}
