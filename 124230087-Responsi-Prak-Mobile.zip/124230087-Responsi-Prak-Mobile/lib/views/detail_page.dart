import 'package:flutter/material.dart';
import '../models/product.dart';
import '../controllers/cart_controller.dart';

class DetailPage extends StatefulWidget {
  static const routeName = '/detail';
  final Product product;

  const DetailPage({super.key, required this.product});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  final CartController _cartCtrl = CartController();
  bool _isInCart = false;
  bool _loadingCart = false;

  @override
  void initState() {
    super.initState();
    _checkCart();
  }

  Future<void> _checkCart() async {
    final v = await _cartCtrl.isInCart(widget.product.id);
    if (mounted) setState(() => _isInCart = v);
  }

  Future<void> _toggleCart() async {
    setState(() => _loadingCart = true);
    if (_isInCart) {
      await _cartCtrl.removeFromCart(widget.product.id);
    } else {
      await _cartCtrl.addToCart(widget.product);
    }
    final v = await _cartCtrl.isInCart(widget.product.id);
    if (mounted) {
      setState(() {
        _isInCart = v;
        _loadingCart = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isInCart
              ? 'Ditambahkan ke keranjang'
              : 'Dihapus dari keranjang'),
          backgroundColor: const Color(0xFFE91E63),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 0, 0, 0),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Detail Product'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        height: 250,
                        padding: const EdgeInsets.all(16),
                        child: p.image.isNotEmpty
                            ? Image.network(
                                p.image,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => const Center(
                                    child: Icon(Icons.broken_image, size: 64)),
                              )
                            : const Center(child: Icon(Icons.image, size: 64)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      p.title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '\$${p.price.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFE91E63),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Chip(
                          label: Text(p.category.toUpperCase()),
                        ),
                        if (p.rating != null) ...[
                          const SizedBox(width: 8),
                          const Icon(Icons.star, size: 16, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text('${p.rating!.toStringAsFixed(1)}'),
                          if (p.ratingCount != null)
                            Text(' (${p.ratingCount} reviews)',
                                style: const TextStyle(color: Colors.grey)),
                        ],
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Description',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      p.description,
                      style: const TextStyle(height: 1.5),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: ElevatedButton.icon(
                onPressed: _loadingCart ? null : _toggleCart,
                icon: _loadingCart
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : Icon(_isInCart
                        ? Icons.remove_shopping_cart
                        : Icons.add_shopping_cart),
                label: Text(_isInCart ? 'Remove from Cart' : 'Add to Cart'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isInCart
                      ? Colors.grey
                      : const Color.fromARGB(255, 0, 0, 0),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
