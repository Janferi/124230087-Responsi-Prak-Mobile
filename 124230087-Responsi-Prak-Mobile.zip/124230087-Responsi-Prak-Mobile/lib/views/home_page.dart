import 'package:flutter/material.dart';
import '../controllers/product_controller.dart';
import '../models/product.dart';
import 'detail_page.dart';

class HomePage extends StatefulWidget {
  static const routeName = '/home';
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ProductController _productCtrl = ProductController();

  @override
  void initState() {
    super.initState();
    _productCtrl.loadProducts();
    _productCtrl.loadCategories();
  }

  @override
  void dispose() {
    _productCtrl.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    await _productCtrl.loadProducts();
    await _productCtrl.loadCategories();
  }

  void _openDetail(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailPage(product: product)),
    );
  }

  void _onCategorySelected(String? category) {
    _productCtrl.filterByCategory(category);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 0, 0, 0),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('E-commerce App'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed('/cart');
            },
            icon: const Icon(Icons.shopping_cart, color: Colors.white),
            tooltip: 'Cart',
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed('/profile');
            },
            icon: const Icon(Icons.person),
            tooltip: 'Profile',
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            AnimatedBuilder(
              animation: _productCtrl,
              builder: (context, _) {
                final categories = _productCtrl.categories;
                if (categories.isEmpty) {
                  return const SizedBox.shrink();
                }

                return Container(
                  color: Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        FilterChip(
                          label: const Text('All'),
                          selected: _productCtrl.selectedCategory == null,
                          onSelected: (selected) {
                            if (selected) _onCategorySelected(null);
                          },
                          selectedColor:
                              const Color(0xFF1A237E).withOpacity(0.2),
                        ),
                        const SizedBox(width: 8),
                        ...categories.map((category) => Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: FilterChip(
                                label: Text(category.toUpperCase()),
                                selected:
                                    _productCtrl.selectedCategory == category,
                                onSelected: (selected) {
                                  if (selected) _onCategorySelected(category);
                                },
                                selectedColor:
                                    const Color(0xFF1A237E).withOpacity(0.2),
                              ),
                            )),
                      ],
                    ),
                  ),
                );
              },
            ),
            Expanded(
              child: AnimatedBuilder(
                animation: _productCtrl,
                builder: (context, _) {
                  if (_productCtrl.loading && _productCtrl.items.isEmpty) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final items = _productCtrl.items;

                  if (items.isEmpty) {
                    return RefreshIndicator(
                      onRefresh: _onRefresh,
                      child: ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: const [
                          SizedBox(height: 120),
                          Center(child: Text('Tidak ada produk')),
                        ],
                      ),
                    );
                  }

                  return RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: GridView.builder(
                      padding: const EdgeInsets.all(8),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.65,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                      ),
                      itemCount: items.length,
                      itemBuilder: (context, idx) {
                        final product = items[idx];
                        return GestureDetector(
                          onTap: () => _openDetail(product),
                          child: Card(
                            color: Colors.white,
                            clipBehavior: Clip.hardEdge,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: product.image.isNotEmpty
                                        ? Image.network(
                                            product.image,
                                            fit: BoxFit.contain,
                                            errorBuilder: (_, __, ___) =>
                                                const Center(
                                                    child: Icon(
                                                        Icons.broken_image)),
                                          )
                                        : const Center(
                                            child: Icon(Icons.image)),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 8),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        product.title,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        '\$${product.price.toStringAsFixed(2)}',
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Color.fromARGB(255, 0, 0, 0),
                                        ),
                                      ),
                                      if (product.rating != null)
                                        Row(
                                          children: [
                                            const Icon(Icons.star,
                                                size: 14, color: Colors.amber),
                                            const SizedBox(width: 4),
                                            Text(
                                              product.rating!
                                                  .toStringAsFixed(1),
                                              style:
                                                  const TextStyle(fontSize: 12),
                                            ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
