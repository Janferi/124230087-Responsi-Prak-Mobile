import 'package:flutter/material.dart';
import '../controllers/cart_controller.dart';
import '../models/product.dart';
import 'detail_page.dart';

class CartPage extends StatefulWidget {
  static const routeName = '/cart';
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final CartController _cartCtrl = CartController();

  @override
  void initState() {
    super.initState();
    _cartCtrl.loadCart();
  }

  @override
  void dispose() {
    _cartCtrl.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    await _cartCtrl.loadCart();
  }

  void _openDetail(Product product) {
    Navigator.of(context)
        .push(
      MaterialPageRoute(builder: (_) => DetailPage(product: product)),
    )
        .then((_) {
      _cartCtrl.loadCart();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 0, 0, 0),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Shopping Cart'),
      ),
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _cartCtrl,
          builder: (context, _) {
            if (_cartCtrl.loading && _cartCtrl.cartItems.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }

            final items = _cartCtrl.cartItems;

            if (items.isEmpty) {
              return RefreshIndicator(
                onRefresh: _onRefresh,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: const [
                    SizedBox(height: 120),
                    Center(
                      child: Column(
                        children: [
                          Icon(Icons.shopping_cart_outlined,
                              size: 64, color: Colors.grey),
                          SizedBox(height: 16),
                          Text('Keranjang belanja kosong',
                              style: TextStyle(fontSize: 16)),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }

            return Column(
              children: [
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: ListView.separated(
                      padding: const EdgeInsets.all(8),
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, idx) {
                        final product = items[idx];
                        return Card(
                          color: Colors.white,
                          child: ListTile(
                            onTap: () => _openDetail(product),
                            leading: SizedBox(
                              width: 56,
                              child: AspectRatio(
                                aspectRatio: 1,
                                child: product.image.isNotEmpty
                                    ? Image.network(
                                        product.image,
                                        fit: BoxFit.contain,
                                        errorBuilder: (_, __, ___) =>
                                            const Center(
                                                child:
                                                    Icon(Icons.broken_image)),
                                      )
                                    : const Center(child: Icon(Icons.image)),
                              ),
                            ),
                            title: Text(
                              product.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '\$${product.price.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 26, 23, 24),
                              ),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline,
                                  color: Colors.red),
                              onPressed: () async {
                                final messenger = ScaffoldMessenger.of(context);
                                final confirm = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text('Hapus dari keranjang?'),
                                    content: Text(
                                        'Hapus "${product.title}" dari keranjang?'),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(ctx, false),
                                        child: const Text('Batal'),
                                      ),
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(ctx, true),
                                        child: const Text('Hapus'),
                                      ),
                                    ],
                                  ),
                                );
                                if (confirm == true) {
                                  await _cartCtrl.removeFromCart(product.id);
                                  messenger.showSnackBar(
                                    const SnackBar(
                                      content: Text('Dihapus dari keranjang'),
                                      backgroundColor: Color(0xFFE91E63),
                                    ),
                                  );
                                }
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
