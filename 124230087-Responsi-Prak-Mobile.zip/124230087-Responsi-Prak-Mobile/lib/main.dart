import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'local/shared_pref.dart';
import 'models/user.dart';
import 'views/login_page.dart';
import 'views/register_page.dart';
import 'views/home_page.dart';
import 'views/cart_page.dart';
import 'views/profile_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(UserAdapter());
  final session = await SharedPref.getSession();

  final initialRoute =
      session != null ? HomePage.routeName : LoginPage.routeName;
  runApp(MyApp(initialRoute: initialRoute));
}

class MyApp extends StatelessWidget {
  final String initialRoute;
  const MyApp({super.key, this.initialRoute = LoginPage.routeName});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'E-commerce App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: initialRoute,
      routes: {
        LoginPage.routeName: (_) => const LoginPage(),
        RegisterPage.routeName: (_) => const RegisterPage(),
        HomePage.routeName: (_) => const HomePage(),
        CartPage.routeName: (_) => const CartPage(),
        ProfilePage.routeName: (_) => const ProfilePage(),
      },
    );
  }
}
