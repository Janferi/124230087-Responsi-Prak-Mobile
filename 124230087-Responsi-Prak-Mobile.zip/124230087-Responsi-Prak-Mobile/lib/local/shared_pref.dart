import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';

class SharedPref {
  static const String _sessionKey = 'session_username';
  static const String _cartKey = 'cart_product_ids';
  static const String _userBoxName = 'users';

  

    static Future<void> saveSession(String username) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_sessionKey, username);
  }

    static Future<String?> getSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sessionKey);
  }

    static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_sessionKey);
  }

  

    static Future<List<int>> getCartProductIds() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_cartKey) ?? [];
    return list.map((s) => int.parse(s)).toList();
  }

    static Future<void> addToCart(int productId) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_cartKey) ?? [];

    
    if (!list.contains(productId.toString())) {
      list.add(productId.toString());
      await prefs.setStringList(_cartKey, list);
    }
  }

    static Future<void> removeFromCart(int productId) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_cartKey) ?? [];
    list.remove(productId.toString());
    await prefs.setStringList(_cartKey, list);
  }

    static Future<bool> isInCart(int productId) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_cartKey) ?? [];
    return list.contains(productId.toString());
  }

    static Future<void> clearCart() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_cartKey);
  }

  

    static Future<void> saveUser(User user) async {
    final box = await Hive.openBox<User>(_userBoxName);
    await box.put(user.username, user);
  }

    static Future<bool> isUserRegistered(String username) async {
    final box = await Hive.openBox<User>(_userBoxName);
    return box.containsKey(username);
  }

    static Future<bool> validateUser(String username, String password) async {
    final box = await Hive.openBox<User>(_userBoxName);
    final user = box.get(username);
    if (user == null) return false;
    return user.password == password;
  }

    static Future<User?> getUser(String username) async {
    final box = await Hive.openBox<User>(_userBoxName);
    return box.get(username);
  }
}
