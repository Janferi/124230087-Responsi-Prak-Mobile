package com.example.latihan_responsi_prak_mobile_124230087

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
