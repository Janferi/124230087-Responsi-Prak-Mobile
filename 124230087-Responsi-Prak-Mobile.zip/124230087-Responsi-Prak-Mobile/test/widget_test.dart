import 'package:flutter_test/flutter_test.dart';
import 'package:latihan_responsi_prak_mobile_124230087/main.dart';

void main() {
  testWidgets('App renders login screen', (tester) async {
    await tester.pumpWidget(const MyApp());

    // Expect the login page to be shown by default
    expect(find.text('Login'), findsOneWidget);
  });
}
